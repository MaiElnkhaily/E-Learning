namespace ELearningManagementSystem.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class Course_Schedule
    {
        public int Id { get; set; }

        [StringLength(40)]
        public string Course_Code { get; set; }

        public int? Duration { get; set; }

        [StringLength(30)]
        public string Day { get; set; }

        [Column(TypeName = "date")]
        public DateTime? StartDate { get; set; }

        [Column(TypeName = "date")]
        public DateTime? EndDate { get; set; }

        public virtual Cours Cours { get; set; }
    }
}
