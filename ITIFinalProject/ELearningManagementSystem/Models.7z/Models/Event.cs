namespace ELearningManagementSystem.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("Event")]
    public partial class Event
    {
        public int Id { get; set; }

        public string Text { get; set; }

        public int? Admin_Id { get; set; }

        [StringLength(1000)]
        public string Adress { get; set; }

        public string Image { get; set; }

        public bool? Active { get; set; }

        [Column(TypeName = "date")]
        public DateTime? Date { get; set; }

        public bool? Visible { get; set; }

        public virtual Admin Admin { get; set; }
    }
}
