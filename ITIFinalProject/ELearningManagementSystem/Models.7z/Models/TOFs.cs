﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ELearningManagementSystem.Models
{
    public enum TOFs
    {
        True,
        False
    }
}